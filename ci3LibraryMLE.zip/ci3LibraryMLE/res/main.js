$(document).ready(function() {
    $('.table').DataTable({
        paging: true,
        searching: true,
        ordering: true,
        info: true
    });
});
