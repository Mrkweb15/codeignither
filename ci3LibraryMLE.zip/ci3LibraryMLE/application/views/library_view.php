
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library</title>
    <link rel="stylesheet" href="<?php echo base_url('res/dataTables.dataTables.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('res/bootstrap.min.css'); ?>">
</head>
<body>
    <div class="container mt-5 pt-5">
        <?php if ($this->session->flashdata('message')): ?>
            <?= $this->session->flashdata('message'); ?>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h2 class="text-primary">Welcome <?= $this->session->userdata('user_name');?></h2>
                <h3>Book List</h3>
            </div>
            <div class="card-body">
                <!-- navs -->
                <ul class="nav nav-tabs" id="bookTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link active" id="tab-available-tab" data-bs-toggle="tab" href="#tab-available" role="tab" aria-controls="tab-available" aria-selected="true">Available</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" id="tab-borrowed-tab" data-bs-toggle="tab" href="#tab-borrowed" role="tab" aria-controls="tab-borrowed" aria-selected="false">Transactions</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" id="tab-addbook-tab" data-bs-toggle="tab" href="#tab-addbook" role="tab" aria-controls="tab-addbook" aria-selected="false">Add Book</a>
                    </li>
                </ul>


                <div class="tab-content mt-3" id="bookTabsContent">
                    <!-- Books Tab -->
                    <div class="tab-pane fade show active" id="tab-available" role="tabpanel" aria-labelledby="tab-available-tab">
                        <h5>Books</h5>
                        <table class="table table-sm table-striped table-bordered">
                            <thead class="table-dark text-center">
                                <tr>
                                    <td>ID</td>
                                    <td>TITLE</td>
                                    <td>AUTHOR</td>
                                    <td>YEAR</td>
                                    <td>STATUS</td>
                                    <td colspan="2">Action</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($books as $book) {?>
                                    <tr>
                                        <td><?= $book['id'];?></td>
                                        <td><?= $book['title'];?></td>
                                        <td><?= $book['author'];?></td>
                                        <td><?= $book['published_year'];?></td>
                                        <td><?= $book['status'];?></td>
                                        <td>
                                            <?php if($book['status'] == "Borrowed") { ?>
                                                <a href="<?= site_url('Library/return_book/' . $book['id']) ?>" class="btn btn-success">Return</a>
                                            <?php } elseif($book['status'] == "Available") { ?>
                                                <a href="<?= site_url('Library/borrow/' . $book['id'])?>" class="btn btn-info">Borrow</a>
                                            <?php } ?>
                                        </td>
                                        <td>
                                            <a  href="<?= site_url('Library/delete/' . $book['id'])?>" class="btn btn-danger">Delete</a>
                                        </td>
                                    </tr>
                                <?php }?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Transactions Tab -->
                    <div class="tab-pane fade" id="tab-borrowed" role="tabpanel" aria-labelledby="tab-borrowed-tab">
                        <h5>Transactions</h5>
                        <table class="table table-sm table-striped table-bordered">
                            <thead class="table-dark text-center">
                                <tr>
                                    <td>Title</td>
                                    <td>Published Year</td>
                                    <td>Borrower</td>
                                    <td>Borrowed Date</td>
                                    <td>Return Date</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($transactions)): ?>
                                    <?php foreach ($transactions as $t): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($t['Title']) ?></td>
                                            <td><?= htmlspecialchars($t['published_year']) ?></td>
                                            <td><?= htmlspecialchars($t['name']) ?></td>
                                            <td><?= htmlspecialchars($t['borrowed_date']) ?></td>
                                            <td><?= $t['return_date'] ? htmlspecialchars($t['return_date']) : '<span class="text-danger">Not Returned</span>' ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="4" class="text-center">No transactions found.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Add Books Tab -->
                    <div class="tab-pane fade" id="tab-addbook" role="tabpanel" aria-labelledby="tab-addbook-tab">
                        <h5>Add Book</h5>
                        <form action="<?= site_url('Library/add'); ?>" method="post">
                            <div class="form-group">
                                <label for="title">Book Title</label>
                                <input type="text" class="form-control" id="title" name="title" placeholder="Title">
                            </div>
                            <div class="form-group">
                                <label for="author">Author</label>
                                <input type="text" class="form-control" id="author" name="author" placeholder="Author">
                            </div>
                            <div class="form-group">
                                <label for="published_year">Year Published</label>
                                <input type="number" class="form-control" id="published_year" name="published_year" placeholder="Year">
                            </div>
                            <div class="form-group mt-3">
                                <button type="submit" class="btn btn-success">Submit</button>
                            </div>
                        </form>

                    </div>
                </div>

            </div>
        </div>

        <a href="<?= site_url('Auth/logout') ?>" class="btn btn-success">Logout</a>
    </div>
    
    <script src="<?php echo base_url('res/dataTables.min.js'); ?>"></script>
    <script src="<?php echo base_url('res/bootstrap.bundle.min.js'); ?>"></script>
    <script src="<?php echo base_url('res/jquery.min.js'); ?>"></script>
    <script src="<?php echo base_url('res/main.js'); ?>"></script>
</body>
</html>