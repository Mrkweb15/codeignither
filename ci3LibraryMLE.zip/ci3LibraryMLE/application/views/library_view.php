<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../res/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.slim.min.js" integrity="sha256-kmHvs0B+OpCW5GVHUNjv9rOmY0IvSIRcf7zGUDTDQM8=" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container mt-5 pt-5">
        <div class="card">
            <div class="card-header">
                <h2>Library Management System</h2>
            </div>
            <div class="card-body">
                <h3>Book List</h3>
                <table class="table table-sm table-stripe">
                    <thead class="table-dark">
                        <tr>
                            <td>ID</td>
                            <td>TITLE</td>
                            <td>AUTHOR</td>
                            <td>YEAR</td>
                            <td>STATUS</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($books as $book) {?>
                            <tr>
                                <td><?= $book['id'];?></td>
                                <td><?= $book['title'];?></td>
                                <td><?= $book['author'];?></td>
                                <td><?= $book['published_year'];?></td>
                                <td><?= $book['status'];?></td>
                            </tr>
                        <?php }?>
                    </tbody>
                </table>
            </div>
        </div>

        <a href="<?= site_url('Auth/logout') ?>" class="btn btn-success">Logout</a>
    </div>
</body>
</html>