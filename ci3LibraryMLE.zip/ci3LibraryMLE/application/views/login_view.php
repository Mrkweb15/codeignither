

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../res/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.slim.min.js" integrity="sha256-kmHvs0B+OpCW5GVHUNjv9rOmY0IvSIRcf7zGUDTDQM8=" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container mt-5 pt-5">
        <div class="card">
            <form action="<?= site_url('Auth/process_login') ?>" method="POST">
                <div class="card-header">
                    <h1 class="text-primary text-center">Login</h1>
                </div>
                <div class="card-body">
                    <?php if($this->session->flashdata('error')): ?>
                        <p class="error"><?= $this->session->flashdata('error'); ?></p>
                    <?php endif; ?>

                    <label for="email" class="form-label">email</label>
                    <input type="text" class="form-control" id="email" name="email">

                    <label for="password" class="form-label">Password</label>
                    <input type="text" class="form-control" id="password" name="password">
                </div>
                <div class="card-footer">
                    <button type="submit" class="w-100 btn btn-primary">Login</button>
                    <a href="<?= site_url('Auth/register') ?>" class="">Register</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>