<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../res/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.slim.min.js" integrity="sha256-kmHvs0B+OpCW5GVHUNjv9rOmY0IvSIRcf7zGUDTDQM8=" crossorigin="anonymous"></script>
</head>
<body>
    <div class="card">
        <div class="card-header">
            <h1 class="text-primary">Welcome to Library</h1>
        </div>
        <div class="card-body">
            <?php if($this->session->userdata('user_id')) { ?>
                <a href="<?= site_url('Library') ?>" class="btn btn-success">Go to Library</a>
                <a href="<?= site_url('Auth/logout') ?>" class="btn btn-warning">Logout</a>
            <?php } else { ?>
                <a href="<?= site_url('Auth/login') ?>" class="btn btn-warning">Login</a>
                <a href="<?= site_url('Auth/Register') ?>" class="btn btn-warning">Register</a>
            <?php } ?>
        </div>
    </div>
</body>
</html>