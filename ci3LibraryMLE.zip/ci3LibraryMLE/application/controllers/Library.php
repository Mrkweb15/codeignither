<?php
    class Library extends CI_Controller{

        public function __construct(){
            parent::__construct();
            $this->load->model('Book_model');
            $this->load->model('Borrow_model');
            $this->load->library('session');
            $this->load->helper('url');

            if(!$this->session->userdata('user_id')){
                redirect('Main');
            }
        }


        public function delete($id) {
            if ($this->Book_model->delete_book($id)) {
                $this->session->set_flashdata('message', '<div class="alert alert-success">Book deleted successfully.</div>');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Failed to delete the book.</div>');
            }
            redirect('library');
        }
        

        public function borrow($book_id){
            $this->Borrow_model->borrow_book($this->session->userdata('user_id'), $book_id);
            redirect('library');
        }

        public function return_book($book_id){
            $this->Borrow_model->return_book($book_id);
            redirect('library');
        }

        public function index(){
            $data['books'] = $this->Book_model->get_books();
            $data['transactions'] = $this->Borrow_model->get_transactions();
            $this->load->view('library_view', $data);
        }

        public function add(){
            $data = [
                'title' => $this->input->post('title'),
                'author' => $this->input->post('author'),
                'published_year' => $this->input->post('published_year'),
                'status' => 'Available'
            ];
        
            if ($this->Book_model->add_books($data)) {
                $this->session->set_flashdata('message', '<div class="alert alert-success">Book added successfully.</div>');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger">Failed to add book.</div>');
            }
        
            redirect('library');
        }
        
        
    }
?>