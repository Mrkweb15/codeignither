<?php
    class Library extends CI_Controller{

        public function __construct(){
            parent::__construct();
            $this->load->model('Book_model');
            $this->load->helper('url');
        }

        public function index(){
            $data['books'] = $this->Book_model->get_books();
            $this->load->view('library_view', $data);
        }
    }
?>